﻿using System;

namespace practice
{
    class Program
    { 
        public static void Main(string[] args)
        {

            /* reverse string
            string str = "welcome to c#";
            string[] str1 = str.Split(" ");
            for(int i=0;i<str1.Length;i++)
            {
                Console.Write(Reverse(str1[i])+" ");
            }
            static string Reverse(string str)
            {
                string rev =string.Empty;
                for(int i=str.Length-1;i>=0;i--)
                {
                    rev+=str[i];
                }
                return rev;
            }
            */
            //string compress
            /*
            string str = "abbcccdddeeee";
            Console.WriteLine(Compress(str));

            static string Compress(string str)
            {
                string newstr = "";
                for(int i=0;i<str.Length;i++)
                {
                    int count = 1;

                    while(i<str.Length-1&&str[i]==str[i+1])
                    {
                        count++;
                        i++;
                    }
                    newstr += str[i];
                    if(count>1)
                    {
                        newstr += count.ToString();
                    }
                    
                }
                return newstr;
            }
           */

            /*
            static int Addition(params int [] arr)
            {
                int s = 0;
                foreach(var item in arr)
                {
                    s += item;
                }
                return s;
            }
            static int Calc(int x, int y,out int d,out int m)
            {
                int z = x + y;
                d = x / y;
                m = x * y;
                return z;
            }
            static void Main(string[] args)
            {
                int r = Addition(3, 4, 6, 8, 9);
                Console.WriteLine("Result is : " + r);*/

            /* int a, d, m = 0;
             a = Calc(5, 6, out d, out m);
             Console.WriteLine("Addition : " + a);
             Console.WriteLine("Division : " + d);
             Console.WriteLine(" Multiplication : " + m);*/
            /* Console.Write(" Enter any name :");
             string str = Console.ReadLine();
             Console.WriteLine();
             string []str1 = str.Split(" ");
             /*for (int i = 0; i < str1.Length; i++)
             {
                 Console.Write(str1[i]);

             for(int i=0;i<str1.Length-1;i++)
             {
                 char[] ch = str1[i].ToCharArray();

                 Console.Write(ch[0] + ".");
             }
             Console.WriteLine(" "+str1[str1.Length - 1]);*/



            //string str = "this is Message";

            //int ctr = 0;
            /*  Console.Write("Enter any string : ");
              string str = Console.ReadLine();
              char []str1 = str.ToCharArray();
              char[]str2 = str.ToCharArray();

              int f = 0, l = str1.Length-1;
              while(f<l)
              {
                  char temp = str1[f];
                  str1[f] = str1[l];
                  str1[l] = temp;
                  f++;
                  l--;


              }*/


            // Console.WriteLine(str1.Equals(str2));
            /* if(b)
             {
                 Console.WriteLine("Yes Palindrome");
             }
             else
             {
                 Console.WriteLine("No Palindrome");
             }
             Console.ReadLine();*/
            /* quest =2
            Console.Write("Enter Full Name : ");
            string str = Console.ReadLine();
            string nstr = str.ToUpper();
            Console.WriteLine("\n In Capital : " + nstr); */


            /*    Ouest  =  1
             * Console.Write("Enter the Email Address : ");
             string str = Console.ReadLine();

             string[] nstr = str.Split("@");
             Console.WriteLine("\nUserName : " +nstr[0]);
             Console.WriteLine(" Domain : " + nstr[1]);
            */
            /* string nstr = str.Insert(9, " new data ");
             Console.WriteLine(" Original :" + str);
             Console.WriteLine(" Output : " + nstr);
            */
            /* string nstr = str.Replace("is", "are");
             Console.WriteLine("Original :" + str);
             Console.WriteLine("Output :" + nstr);
            */
            /* string nstr = str.Remove(4, 6);
             Console.WriteLine("original : " + str);
             Console.WriteLine("output : " + nstr); */

            /* string[] sarr = str.Split(" ");

             for(int i=0;i<sarr.Length;i++)
             {
                 Console.WriteLine("Index : " + i + "word : " + sarr[i]);
             }
            */
            /* 
             char[] charr = str.ToCharArray();
               for(int i=0;i<charr.Length;i++)
               {
                   Console.WriteLine("Index : " + i + "char : " + charr[i]);
               }

              */


            //string str2 = str.Substring(3, 2);


            // Console.WriteLine(str.IndexOf("s"));
            // Console.WriteLine(str.LastIndexOf("s"));

            //Console.WriteLine(str.StartsWith("e"));
            //Console.WriteLine(str.EndsWith("e"));

            // Console.WriteLine("original :" + str);
            //Console.WriteLine("Sub : " + str2);
        }
    }
}

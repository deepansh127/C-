﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Properties
{
    class BankingCustomer

    {
        private string _AcNo;
        public string Name;
        private decimal _Amount;
        decimal n;

        public BankingCustomer (string acNo,string name,decimal amount)
        {
            _AcNo = acNo;
            Name = name;
            _Amount = amount;
        }
        public string AcNo => _AcNo;
        public decimal N
        {
            set => n = value;
            get => _Amount;
        }
        public decimal Amount
        {
            get { return _Amount; }
            set
            {
                if (value <= 0)
                    _Amount = 123;
                else
                    _Amount = value;

            }
        }
    }
}

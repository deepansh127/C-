﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ineritance
{
    class Employee
    {
        int empId;string empName;double empSalary;
        public void GetEmpData()
        {
            Console.WriteLine("Enter Employee Details ");
            Console.WriteLine("Employee Id :");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Employee Name :");
            empName = Console.ReadLine();
            Console.WriteLine("Employee Salary");
            empSalary = Convert.ToDouble(Console.ReadLine());

        }
        public void DisplayEmpData()
        {
            Console.WriteLine($"Employee Id : {empId} ,Employee Name : {empName} ,Employee Salary : {empSalary}");
        }
    }

    class Trainer:Employee
    {
        string subject;
        public void GetSubInfo()
        {
            base.GetEmpData();
            Console.WriteLine("Enter Your Subject : ");
            subject = Console.ReadLine();
            
        }
        public void DisplaySub()
        {
            base.DisplayEmpData();
            Console.WriteLine("Subject is : " + subject);
        }
    }
    class Admin:Employee
    {
        public void BSchedule()
        {
            Console.WriteLine("Batch Scheduling");
        }
    }
    class Finance : Employee
    {
        public void Taxcal()
        {
            Console.WriteLine(" Tax Calculation");
        }
    }
    class Program1
    {
        static void Main(string[] args)
        {
            /* Trainer obj = new Trainer();
            // obj.GetEmpData();
             obj.GetSubInfo();
             //obj.DisplayEmpData();
             obj.DisplaySub();*/

            /*  Admin ab = new Admin();
              ab.GetEmpData();
              ab.DisplayEmpData();
              ab.BSchedule();*/
            Finance f = new Finance();
            f.GetEmpData();
            f.DisplayEmpData();
            f.Taxcal();
            
        }
    }
}

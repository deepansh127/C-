﻿using System;
using System.Text;

namespace Assesment5
{
    class Program
    {
        static void Main(string[] args)
        {

            #region practice
            /*
            var today = DateTime.Now;
            Console.WriteLine(today.Year);

            Console.WriteLine(today.Day);
            Console.WriteLine(today.DayOfWeek);
            Console.WriteLine(today.Month);
            Console.WriteLine(today.DayOfWeek);
            Console.WriteLine(today.Hour);
            Console.WriteLine(today.Minute);
            Console.WriteLine(today.Second);
            Console.WriteLine(today.Millisecond);

            // Random random = new Random();
            // var otp = random.Next(111111, 999999);
            //Console.WriteLine(otp);
            
            string ename = "Ramesh";
            string empId = "EMP00912";

            StringBuilder sb = new StringBuilder("Dear team\n\t<username> Hope you are doing good ,\n\tyour employee id <employeeId> is attached with our System");
            sb.Replace("<username>", ename);
            sb.Replace("<employeeId>", empId);
            Console.WriteLine(sb);
            

            StringBuilder sb = new StringBuilder("This is my string");

              Console.WriteLine(sb);

              sb.Append(" for building");
              Console.WriteLine(sb);

              sb.Insert(7," a");
              Console.WriteLine(sb);

              */
            #endregion

            #region quest 1  Add two Matrix
            /*  int[,] arr1 = new int[3, 3];
              int[,] arr2 = new int[3, 3];
              int[,] arr3 = new int[3, 3];

              Console.WriteLine("Enter the element of 1st Matrix");
              for(int i=0;i<3;i++)
              {
                  for(int j=0;j<3;j++)
                  {
                      arr1[i, j] = int.Parse(Console.ReadLine());

                  }
                  Console.WriteLine();

              }
              Console.WriteLine("Enter the element of 2nd Matrix");
              for (int i = 0; i < 3; i++)
              {
                  for (int j = 0; j < 3; j++)
                  {
                      arr2[i,j] = int.Parse(Console.ReadLine());

                  }
                  Console.WriteLine();

              }
              Console.WriteLine("Addition of two Matrix");
              for (int i = 0; i < 3; i++)
              {
                  for (int j = 0; j < 3; j++)
                  {

                      arr3[i, j] = arr1[i, j] + arr2[i, j];
                      Console.Write(arr3[i, j] + " ");
                  }
                  Console.WriteLine();
              } */
            #endregion

            #region quest 2 Multiply
            /*
            int[,] arr1 = new int[3, 3];
            int[,] arr2 = new int[3, 3];
            int[,] arr3 = new int[3, 3];

            Console.WriteLine("Enter the element of 1st Matrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr1[i, j] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine();

            }
            Console.WriteLine("Enter the element of 2nd Matrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr2[i, j] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine();

            }
            Console.WriteLine("Multiplication of two Matrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    int temp = 0;
                    for(int k=0;k<3;k++)
                    {
                        temp += arr1[i, k]*arr2[k, j];
                    }
                    arr3[i, j] = temp;
                  Console.Write(arr3[i, j] + " ");
                }
                Console.WriteLine();

            }

            */
            #endregion

            #region quest 3 Transpose
            /*int[,] arr1 = new int[3, 3];
            int[,] arr2 = new int[3, 3];
            

            Console.WriteLine("Enter the element of Matrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr1[i, j] = int.Parse(Console.ReadLine());
                    arr2[j, i] = arr1[i, j];
                }
                Console.WriteLine();

            }
            Console.WriteLine("Transpose of Matrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(arr2[i, j]+" ");
                }
                Console.WriteLine();

            }

            */
            #endregion
        }
    }
}

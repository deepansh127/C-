﻿using System;

namespace StringPractice
{

    #region DuplicateCharacter
    /*
    class DuplicateCharacter
    {
        public void duplicate()
        {
            Console.WriteLine("Enter String");
            string str = Console.ReadLine();
            
            char[] temp = str.ToCharArray().;
            char[] temp1 = new char[temp.Length];
            int index = 0;
            foreach(var item in temp)
            {
                if(checkExist(temp1,item)<1)
                {
                    if (checkExist(temp, item) > 1)
                    {
                        Console.WriteLine("Duplicate : " + item);
                        temp1[index] = item;
                        index++;
                    }
                }
            }
        }
        public int checkExist(char[] temp,char item)
        {
            int ctr = 0;
            for(int i = 0; i < temp.Length; i++)
            {
                if(temp[i]==item)
                {
                    ctr++;
                }
            }
            return ctr;

        }
    }
           */
    #endregion


    #region Replace word in String
    /*
    internal  class Practice
    {      public void replace()
        {
            Console.WriteLine("Enter String");
            String str = Console.ReadLine();
             string [] str1 = str.Split(" ");
            Console.WriteLine("Enter replace Word");
            string rp = Console.ReadLine();
            Console.WriteLine("Enter insert word");
            string iw = Console.ReadLine();

            for(int i=0;i<str1.Length;i++)
            {
                if(str1[i].ToLower()==rp.ToLower())
                {
                    str1[i] = iw;
                    break;
                }    
            }
            for(int i=0;i<str1.Length;i++)
            {
                Console.Write(str1[i] + " ");
            }
        }
    }
    */
    #endregion

    #region CharacterOccurrence
    /*
    class CharacterOccurrence
    {
        public void Occurrence()
        {
            Console.WriteLine("Enter string");
            string str = Console.ReadLine();
            
            char[] temp = str.ToCharArray();
            char[] str1 = new char[temp.Length];
            int index = 0;
            foreach(var item in temp)
            {
                if(checkExist(str1,item)<1)
                {
                    Console.WriteLine("Occurrence : of " + item + " : " + checkExist(temp, item));
                    str1[index] = item;
                    index++;
                }
            }
          
        }
        public int checkExist(char[] temp1, char item)
        {
            int ctr = 0;
            for (int i = 0; i < temp1.Length; i++)
            {
                if (temp1[i] == item)
                {
                    ctr++;
                }
            }

            return ctr;
        }
    }    */
    #endregion

    #region StringPalindrome
    /*
    class Palindrome
    {
        public void palin()
        {
            Console.WriteLine("Enter string");
            string str = Console.ReadLine();
            bool b = check(str);
            if (b)
                Console.WriteLine("yes Plaindrome");
            else
                Console.WriteLine("no Palindrome");
        }
        public bool check(string str)
        {
            for(int i=0;i<str.Length/2;i++)
            {
                if (str[i] != str[str.Length - 1 - i])
                    return false;
            }
            return true;
        }
    }  */
    #endregion

    #region Reverse
    /*
   
    class Reverse
    {
        public void rev()
        {
            Console.WriteLine("Enter String");
            
            string str = Console.ReadLine();
            string []sp =str.Split(" ");
           
            char[] str2 = str.ToCharArray();
            char[] str3 = new char[str2.Length];
            int index = 0;
            Console.WriteLine("Reverse String");

            for(int i=str2.Length-1;i>=0;i--)
            {
                Console.Write(str2[i]);
                str3[index] = str2[i];
                index++;
            }

        }
    }  
         */
    #endregion
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Practice p = new Practice();
            p.replace();   */
            /* DuplicateCharacter dc = new DuplicateCharacter();
             dc.duplicate();  */
            /*  CharacterOccurrence co = new CharacterOccurrence();
              co.Occurrence();  */
            /* Palindrome p = new Palindrome();
             p.palin();  */
          /* Reverse r = new Reverse();
            r.rev();      */
        }
    }
}

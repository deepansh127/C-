﻿using System;
namespace Abstract1
{ 


    /*
    public abstract class Employee
    {
        public string Fname;
        public string Lname;
        public decimal AnualSalary;
        public Employee(string fname)
        {
            Fname = fname;
        }
        public void PrintDetails()
        {
            Console.WriteLine("Employee First Name : "+Fname);
            Console.WriteLine("Employee Last Name : "+Lname);
            Console.WriteLine("Annual Salary : "+AnualSalary);
        }
        public abstract decimal CalculatePerMonthSalary();
    }
    public class SalesEmployee:Employee
    { public decimal Commision=5000;
        public SalesEmployee(string fname):base(fname)
        { }
        public override decimal CalculatePerMonthSalary()
        {
          return AnualSalary / 12 + Commision;
            
        }
         public void PrintChild()
        {
            Console.WriteLine("hello Child");
        }
    }
          */

    abstract class Product
    {
        public int pId;
        public string pName;
        public double mrp;
        public void GetData()
        {
            Console.WriteLine("Enter Product Details : ");
            pId = Convert.ToInt32(Console.ReadLine());
            pName= Console.ReadLine();
            mrp = Convert.ToDouble(Console.ReadLine());

        }
        public abstract void CalPriceWithDiscount(int discount);
        public abstract void Display();
    }
    class BankOffers : Product
    {
        public override void CalPriceWithDiscount(int discount)
        {
            double price = mrp - discount;
            Console.WriteLine("Total Price :  "+price);
        }
        public override void Display()
        {
            Console.WriteLine($"PID is : {pId} , Pname is : {pName} and MRP is : {mrp}");
        }
    }
    class BigBillonDays:Product
    {
        public override void CalPriceWithDiscount(int discount)
        {
            double price = mrp - (discount * 2);
            Console.WriteLine("Price is : "+price);
        }
        public override void Display()
        {
            Console.WriteLine("Welcome to Big Festival Carnival ....!");
            Console.WriteLine($"PID is : {pId} ,PName is : {pName} and MRP is : {mrp}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {  /*
            SalesEmployee em = new SalesEmployee("Nitish");
            em.Lname = "kumar";
            em.AnualSalary = 12000;
            em.PrintDetails();
            Console.WriteLine("salary per month with commision : "+em.CalculatePerMonthSalary());
             */
                 BankOffers b = new BankOffers();
            b.GetData();
            b.Display();
            b.CalPriceWithDiscount(1000);
            BigBillonDays b1 = new BigBillonDays();
            b1.GetData();
            b1.Display();
            b1.CalPriceWithDiscount(1000);
        }
    }
}

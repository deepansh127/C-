﻿using System;

namespace ForLoop
{
    
   internal  class Program
    {
       public  static void Main(string[] args)
        { 
            
           Pattern.H();
            Console.ReadLine();
        }
    }
}

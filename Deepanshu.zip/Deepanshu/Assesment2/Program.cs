﻿using System;

namespace Assesment2
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Quest 1
            /*   int n;
               Console.WriteLine("Enter any number :");
               n = int.Parse(Console.ReadLine());
               for(int i=1;i<=10;i++)
               {

                   Console.WriteLine($"{n}*{i} = {n * i}");
               }
            */
            #endregion

            #region quest 2
            /*
            int n;
            Console.WriteLine("Enter any Number :");
            n = int.Parse(Console.ReadLine());
            int ctr = 0;
            for(int i=1;i<=n;i++)
            {
                if (n %i == 0)
                    ctr++;
            }
            if(ctr==2)
            {
                Console.WriteLine(n+" is prime " );
            }
            else
            {
                Console.WriteLine(n+" is not Prime");
            }*/

            #endregion

            #region quest 3
            /*
            int n;
            Console.WriteLine("Enter any number :");
            n = int.Parse(Console.ReadLine());
            int s = 0;
            while(n>0)
            {
                int r = n % 10;
                s = s*10+r;
                n = n / 10;
            }
            Console.WriteLine("After reverse \n n = " + s);
           */
            #endregion

            #region quest 4
            /*
            int n,f=1;
            Console.WriteLine("Enter any number");
            n = int.Parse(Console.ReadLine());
            while(n>0)
            {
                f = f * n;
                n--;
            }
            Console.WriteLine(" Factorial is : " + f);
            */
            #endregion

            #region quest 5

            /*
            Console.WriteLine("Enter 1st number ");
            int n1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter 2nd number ");
            int n2 = int.Parse(Console.ReadLine());
            int gcd = 1;
            if(n1==n2)
            {
                gcd = n1;
            }
            if(n1>n2)
            {
                int temp = n1;
                n1 = n2;
                n2 = temp;
            }
            int i = 1;
            while(i<=n1)
            {
                if (n1 % i == 0 && n2 % i == 0)
                    gcd = i;
                i++;
            }
            Console.WriteLine("Greates common Division : " + gcd);
            */
            #endregion  

            Console.WriteLine("Enter the terms ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Fibonacci series ");
            int a = 0, b = 1;
            Console.Write(a + " " + b);
            for(int i=1;i<n-1;i++)
            {
                int c = a + b;
                Console.Write(" " + c);
                a = b;
                b = c;
            }




        }
    }
}

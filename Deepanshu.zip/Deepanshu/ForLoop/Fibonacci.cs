﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForLoop
{
    class HCF
    {
        public static void Get()
        {
            Console.WriteLine("Enter two Number ");
            Console.Write(" n1 : ");
            int n1 = Int32.Parse(Console.ReadLine());
            Console.Write("\n n2 : ");
            int n2 = Int32.Parse(Console.ReadLine());

            int gcd = 1;
            if (n1 == n2) ;
            {
                gcd = n1;
            }
            if(n1>n2)
            {
                int temp = n1;
                n1 = n2;
                n2 = temp;
            }
            int i = 1;
            while(i<=n1)
            {
                if((n1%i==0)&&(n2%i==0))
                {
                    gcd = i;
                    

                }
                i++;
            }
            Console.WriteLine("Greates Common Division : " + gcd);




                
        }
    }
}

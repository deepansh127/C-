﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FileHandling
{
    class Content
    {

        public static void AllContent()
        {
            
            string LogPath = @"D:\\ErrorLog\Log_25_01_2023";
            if (File.Exists(LogPath))
            {
                FileStream fs = new FileStream(LogPath, FileMode.Open);
                StreamReader read = new StreamReader(fs);
                string  msg = read.ReadToEnd().ToString();
                
                read.Close();
                Console.WriteLine(msg);

            }

          
        }

    }
}

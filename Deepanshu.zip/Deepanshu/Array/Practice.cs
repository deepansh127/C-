﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Array
{
   internal class Practice
    {
        public static void Array1()
        {
            /*
            int[] num = new int[10];
            for(int i=0;i<num.Length;i++)
            {
                Console.WriteLine("please enter number for {0} index", i);
                
                num[i] = int.Parse(Console.ReadLine());

            }
            for(int i=0;i<num.Length;i++)
            {
                Console.WriteLine("Index :{0}, number : {1} ", i, num[i]);
            }
            int j= 0;
            foreach(int n in num)

            {   
                Console.WriteLine("Index : {0} ,number :{1}",j,n);
                j++;
                    
            } */

            string[] name = { "array", "amit", "suar", "rohit", "rajat" };
            foreach(string name1 in name)
            {
                if (name1.Contains("r"))
                {
                    Console.WriteLine(name1);
                }
                    
            }

            
        }
    }
}

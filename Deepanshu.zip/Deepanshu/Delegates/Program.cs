﻿using System;

namespace Delegates
{
    class Arithmetic
    {
        public void Addition(int a, int b)
        {
            int c = a + b;
            Console.WriteLine("Addition is : " + c);
        }
        public void Substract(int a, int b)
        {
            int c = a - b;
            Console.WriteLine("Substract is : " + c);
        }
        public  void Multiple(int a, int b)
        {
            int c = a * b;
            Console.WriteLine("Multiplication is : " + c);
        }
        
    }
    public delegate void MyDelegate(int x, int y);
    class Program
    {
        static void Main(string[] args)
        {
            int value = 3;
            for (int power = 0; power <= 32; power++)
                Console.WriteLine($"{value}^{power} = {(long)Math.Pow(value, power):N0} (0x{(long)Math.Pow(value, power):X})");

            int s = 0;
            Console.WriteLine(  Math.Sign(s));
            


        }
        public static void PrintMessage()
        {
            Console.WriteLine("print Message");
        }
        public static void Addition(int a,int b)
        {
            int c = a + b;
            Console.WriteLine("Addition is : "+c);
        }
        public static void Substract(int a, int b)
        {
            int c = a - b;
            Console.WriteLine("Substract is : " + c);
        }
        public static void Multiple(int a, int b)
        {
            int c = a * b;
            Console.WriteLine("Multiplication is : " + c);
        }
    }
}

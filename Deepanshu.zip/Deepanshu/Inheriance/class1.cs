﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class Class1
    {  
        static Class1()
        {
            Console.WriteLine("static constructor of class 1");
        }
        public Class1(int x)
        {
            Console.WriteLine("class1 Constructor"+x);
        }
        public void F1()
        {
            Console.WriteLine(" this is F1() of class1");
        }
    }
    class Class2:Class1
    {
        public Class2(string x):base(10)
        {
            Console.WriteLine(" class 2 constructor"+x);
        }
        static Class2()
        {
            Console.WriteLine("Static constructor of class 2");
        }
        public void F2()
        {
            Console.WriteLine("this is f2() of class2");
        }
    }
    class Class3:Class2
    { 
        static Class3()
        {
            Console.WriteLine(" Static constructor class 3");
        }
        public Class3():base("welcome")
        {
            Console.WriteLine("Class3 constructor");
        }
        public void F3()
        {
            Console.WriteLine(" this is F3() of class");
        }
    }
    class Program2
    {
      public  static void Main(string[] args)
        {

            Class3 obj = new Class3();
            obj.F1();
            obj.F2();
            obj.F3();
        }
    }
}

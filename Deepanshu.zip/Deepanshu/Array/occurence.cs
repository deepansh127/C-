﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Array
{
  internal  class occurence
    {  
        public static void Num()
        {
            int[] arr = new int[10];
            for(int i=0;i<arr.Length;i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int[] arr1 = new int[arr.Length];
            for(int i=0;i<arr.Length;i++)
            {
                int ctr = 0;
                if (checkExist(arr1, arr[i]) < 1)
                {
                    for (int j = i; j < arr.Length; j++)
                    {

                        if (arr[i] == arr[j])
                            ctr++;

                    }

                    if (ctr > 0)
                    {
                        arr1[i] = arr[i];
                        Console.WriteLine("number : " + arr1[i] + " , " + ctr + " times");


                    }
                }
                
            }

             static int checkExist(int []arr1,int n)
            {
                int count = 0;
                for(int i=0;i<arr1.Length;i++)
                {
                    if(arr1[i]==n)
                    {
                        count++;
                    }
                }
                return count;
            }
        }
    }
}

﻿using System;

namespace Search
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Bubble sort
            int[] arr = { 6, 3, 8, 10, 2, 9, 1 };
            
            for(int i=0;i<arr.Length-1;i++)
            {
                for(int j=i+1;j<arr.Length;j++)
                {
                    if(arr[i]>arr[j])
                    {
                        int temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
                
            }
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }      */     
            /*   Binaryb search
                         int [] num = {2,5,8,10,15,20};
            int key =5;
            int index = binarySearch(num, key);
            if (index == -1)
                Console.WriteLine("not found");
            else
                Console.WriteLine("key is index : " + index);*/

        }
        static int linearSearch(string []num ,string key)
        {
            for(int i=1;i<num.Length;i++)
            {
                if(num[i]==key)
                {
                    return i;
                }
            }
            return -1;
        }
        static int binarySearch(int []num,int key)
        {
            int st = 0,end = num.Length - 1;
            while(st<=end)
            {
               int mid = (st + end) / 2;
                if (num[mid] == key)
                    return mid;
                if (num[mid] > key)
                    end = mid - 1;
                else if (num[mid] < key)
                    st = mid + 1;
            }
            return -1;
        }
    }
}

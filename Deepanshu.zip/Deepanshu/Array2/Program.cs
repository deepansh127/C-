﻿using System;

namespace Array2
{
    class Program
    {



        #region Array sum
        public static void pract()
        {

            int[] arr1 = new int[5];
            int s1 = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                Console.Write("\n please enter number for {0} index : ", i);
                arr1[i] = int.Parse(Console.ReadLine());

            }
            for (int i = 0; i < arr1.Length; i++)
            {

                s1 = s1 + arr1[i];
            }
            Console.WriteLine("the sum of all element of array : " + s1);
        }
        #endregion

        public static void rnum()
        {
            int []arr = new int[5];
            Console.WriteLine("Enter any five number ");
            for(int i=0;i<arr.Length;i++)
            {
                Console.Write("\nEnter number for index {0} : ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("\nBefore Reverse");            
                for(int i=0;i<arr.Length;i++)
                {
                Console.Write(" " + arr[i]);
                }

                for(int i=0;i<arr.Length;i++)
                {
                  int rev = 0;
                   int n = arr[i];
                    while(n>0)
                    {
                      int r = n % 10;
                       rev = rev * 10 + r;
                       n = n / 10;
                       
                    }
                   arr[i] = rev;
                }
            Console.WriteLine(" \n After Reverse");
            for(int i=0;i<arr.Length;i++)
            {
                Console.Write(" " + arr[i]);
            }
        }

        static void Main(string[] args)
        {
            rnum();
            
        }
    }
}

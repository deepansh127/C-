﻿using System;

namespace Exception1
{
   class A
    {
        public int a = 10;
        public  void M()
        {
            Console.WriteLine("parent Method");
        }
       

    }
    class B : A
    {
    
        public virtual void M()

        {
            Console.WriteLine("Child Method ");

        }

    }
    class C : B
    {
        public new virtual void M()

        {
            Console.WriteLine(" sub Child Method ");

        }

    }
     public enum weekdays
    {
        mon=10,thus,wed
    }
    class Program
    {
        public static void printArr(int []arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i]+" ");
            }
        }



        public static void mergeSort(int []arr,int si,int ei)
        {
            if (si >= ei)
            {
                return;
            }
            int mid = si + (ei - si) / 2;
            mergeSort(arr, si, mid);
            mergeSort(arr, mid + 1, ei);
            Merge(arr, si, mid, ei);
        }
        public static void Merge(int []arr,int si,int mid,int ei)
        {
            int[] temp = new int[ei - si + 1];
            int i = si;
            int j = mid + 1;
            int k = 0;
            while (i <= mid && j <= ei)
            {
                if (arr[i] < arr[j])
                {
                    temp[k] = arr[i];
                    i++;
                    k++;
                }
                else
                {
                    temp[k] = arr[j];
                    j++;
                    k++;
                }
            }
            while (i <= mid)
            {
                temp[k++] = arr[i++];

            }
            while (j <= ei)
            {
                temp[k++] = arr[j++];

            }
            for (k=0,i=si; k < temp.Length; k++,i++)
            {
                arr[i] = temp[k];
            }

        }


        static void Main(string[] args)
        {
            B b = new C();
            b.M();
           // Parent c = new Child();
           // Console.WriteLine(c.M());
            //int[] arr = { 6, 3, 9, 5,4,8,3,2,1};
            //Console.WriteLine("Before sorting ");
            //printArr(arr);
            //mergeSort(arr, 0, arr.Length - 1);

            //Console.WriteLine("\nBefore sorting ");
            //printArr(arr);

         
            //B b = new B();

           //b.M();

            /*int n1;
            int n2;
            int s;
            int z;
            try
            {
                Console.WriteLine("Enter 1st Number");
                 n1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter 2nd Number");
               n2= Convert.ToInt32(Console.ReadLine());
                if (n2 <= 5)
                    throw new MyException("value can not be less than");
                 z = n1 / n2;
               
                Console.WriteLine("Result is : "+z);
                
                
            }
            catch(MyException e)
            {
                Console.WriteLine(e.Message);
            }
           
           /* catch(DivideByZeroException em)
            {
                Console.WriteLine("hii this is : "+em.Message);

                Console.WriteLine("hii this is : " + em.Source);
                Console.WriteLine("hii this is : " + em.StackTrace);

            }
            catch (FormatException em)
            {
                Console.WriteLine("hii this is : " + em.Message);

                Console.WriteLine("hii this is : " + em.Source);
                Console.WriteLine("hii this is : " + em.StackTrace);

            }
            catch (Exception em)
            {
                Console.WriteLine("hii this is : " + em.Message);

                Console.WriteLine("hii this is : " + em.Source);
                Console.WriteLine("hii this is : " + em.StackTrace);

            }
            finally
            {
                int z3=9;
                try
                {
                   // Console.WriteLine("Enter Z3 Number");
                  // z3 = Convert.ToInt32(Console.ReadLine());
                    //Console.WriteLine("Enter 2nd Number");
                    //int n2 = Convert.ToInt32(Console.ReadLine());
                    //int z = n1 / n2;
                    //if (n2 != 0)
                    //{
                    //    Console.WriteLine("if condition");

                    //}

                    Console.WriteLine("Result is : " + z3);
                  
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);

                }
                finally
                {
                    Console.WriteLine("inside finally"+z3);
                }
                Console.WriteLine(" finally block");
            }
            int z4= 8;
            try
            {
                // Console.WriteLine("Enter Z3 Number");
                // z3 = Convert.ToInt32(Console.ReadLine());
                //Console.WriteLine("Enter 2nd Number");
                //int n2 = Convert.ToInt32(Console.ReadLine());
                //int z = n1 / n2;
                //if (n2 != 0)
                //{
                //    Console.WriteLine("if condition");

                //}

                Console.WriteLine("Result is : " + z4);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }
            finally
            {
                Console.WriteLine("inside finally" + z4);
            }
            Console.WriteLine(" outside the hii  block");*/

        }

        static new int Main(int a)
        {
            return a;
        }
    }
}

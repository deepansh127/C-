﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interface
{
    abstract class Ab
    {
       public abstract void z();
        public abstract void A();
    }
    class child : Ab
    {
        int a = 10;
        public void M2()
        {
            Console.WriteLine("method m2");
        }
        public override void A()
        {
            Console.WriteLine(" Method A");
        }
        public override void z()
        {
            Console.WriteLine("Hello World");
        }
        
    }
}

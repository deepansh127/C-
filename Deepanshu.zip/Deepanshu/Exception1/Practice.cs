﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exception1
{
    class Parent
    {
        public virtual int M()
        {
            Console.WriteLine("parent Method");
            return 1;
        }
    }
    class Child : Parent
    {
        public override int M()
        {
            Console.WriteLine(" Child Method");
            return 2;
        }
    }

}

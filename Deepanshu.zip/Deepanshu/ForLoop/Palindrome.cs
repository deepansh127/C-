﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForLoop
{
    internal class Palindrome
    {
        public static void Check()
        {
            int r, n2, p=0;
            Console.WriteLine("Enter any number : ");
            int n1 = Int32.Parse(Console.ReadLine());
            n2 = n1;
            while(n1>0)
            {
                r = n1 %10;
                p= p* 10 + r;
                n1 = n1 /10;

            }
            if (p == n2)
            {
                Console.WriteLine("Number is Palindrome : " + n2);
                Console.WriteLine("   " + p);
            }
            else
            {
                Console.WriteLine("Number is not Palindrome : " + n2);
                Console.WriteLine("   " + p);
               
            }
        }
    }
}

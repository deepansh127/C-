﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interface
{
  internal   interface I2
    {
        void F3();
    }
    internal interface I3
    {
        void F3();
    }
    class class1
    {
        public void F2()
        {
            Console.WriteLine(" this is f2()");
        }
    }
    class class2 : class1, I3, I2
    {
      
        void I2.F3()
        {
            Console.WriteLine(" this is I2()");
        }
        void I3.F3()
        {
            Console.WriteLine(" this is I3()");
        }
    }
}

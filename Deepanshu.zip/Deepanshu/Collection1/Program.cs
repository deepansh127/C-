﻿using System;
using System.Collections;

namespace Collection1
{
    class Program
    {
        static void Main(string[] args)
     {

            //Non-Generic

            #region Arraylist 
            /*
           ArrayList list = new ArrayList();
             list.Add(100);
             list.Add(1.00);
             list.Add(true);
             list.Add("Message");
             list.Add("hii");
             list.Add("hj");

             Console.WriteLine(list.Count);
             Console.WriteLine(list.Capacity);
             foreach (var item in list)
             {
                 Console.Write(item+" ");
             }
             Console.WriteLine();

             list.AddRange(new string[] { "five", "two ", "three" } );

             foreach (var item in list)
             {
                 Console.Write( item+" ");
             }
             Console.WriteLine();

             Console.WriteLine(list.Count);
             Console.WriteLine(list.Capacity);
             list.Remove(1.00);
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();
             list.RemoveAt(1);
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();
             list.RemoveRange(2, 3);
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();
             list.AddRange(new string[] { "five", "two ", "three" });
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();
             list.Insert(2, "I ");
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();
             list.InsertRange(2,new int []{2,6,7});
             foreach (var item in list)
             {
                 Console.Write(item + " ");
             }
             Console.WriteLine();

             Console.WriteLine(list.Contains(6));




             //Exception 
             //foreach (var item in list)
             //{
             //    Console.Write(Convert.ToInt32(item) );
             //}
             //Console.WriteLine();


             Console.WriteLine(list.IndexOf(6));
             list.Reverse(); 
             foreach (var item in list)
             {
                 Console.Write(item+" ");
             }
             Console.WriteLine();
             Console.WriteLine();

             #endregion

             #region stack
             /*
             Stack stk = new Stack();
             stk.Push(100);
             stk.Push("annie");
             stk.Push(11.00);
             stk.Push(400);
             stk.Push(200);
             stk.Push(1);
             foreach(var item in stk)
             {
                 Console.Write(item+" ");
             }
             Console.WriteLine("top most item : "+stk.Peek());
             stk.Pop();
             Console.WriteLine(stk.Contains(400));

            */
            #endregion


            #region Queue
            /*
             Queue queue = new Queue();
             queue.Enqueue(2000);
             queue.Enqueue(400);
             queue.Enqueue(700);
             queue.Enqueue("Annie");


             Console.WriteLine(queue.Count);
             foreach (var item in queue)
             {
                 Console.Write(item+" ");
             }
             Console.WriteLine();
             queue.Dequeue();
             foreach (var item in queue)
             {
                 Console.Write(item+" ");
             }
             Console.WriteLine();
             Console.WriteLine(queue.Peek());
             Console.WriteLine(queue.Contains(400));

             queue.TrimToSize();

             foreach (var item in queue)
             {
                 Console.Write(item + " ");

             }*/
            #endregion


            Hashtable ht = new Hashtable();
            ht.Add(9, "India");
            ht.Add(10, "India");
            ht.Add(11, "USA");
           
           
            ht.Add(13, "India");
            ht.Add(15, "India");
            ht.Add(12, "India");
            ht.Add(19, "India");
            ht.Add(1, "India");
            foreach (DictionaryEntry item in ht)
            {
                Console.WriteLine("country Code : "+item.Key+" Country Name : "+item.Value);
            }
            Console.WriteLine(ht.Clone());
            Console.WriteLine("----");
            foreach (var item in ht.Keys)
            {
                Console.WriteLine(item + "--->" + ht[item]);
            }





        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Array1
{
    internal class Practice
    {
        /*
        public static void pract()
        {
            int[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 2, 4, 6, 8 };
            int[] arr2 = new int[arr1.Length];
            int k = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                for(int j=i+1;j<arr1.Length;j++)
                {
                    if(arr1[i]==arr1[j])
                    {
                        arr2[k] = arr1[i];
                        k++;
                        break;
                    }
                }
            }

            Console.WriteLine("Array ----1");
            for(int i=0;i<arr1.Length;i++)
            {
                Console.WriteLine(" " + arr1[i]);
            }
            Console.WriteLine("\nDuplicate Value");
            for (int i = 0; i < arr2.Length; i++)
            {
                Console.WriteLine(" " + arr2[i]);
            } */
            public  static void Delete()
            {
                int[] arr = { 21, 34, 54, 21, 43, 11, 65 };
            int n = arr.Length;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);

            }
            Console.WriteLine(" enter the number what number do you want to delete");
                int k = int.Parse(Console.ReadLine());
                for (int i = 0; i <n; i++)
                {
                    if (arr[i] == k)
                    {
                        
                        for (int j = i; j < n-1; i++)
                        {
                            arr[j] = arr[j + 1];
                        }
                         n--;                     
                       

                    }
                }
                for (int i = 0; i <n; i++)
                {
                    Console.Write(" " + arr[i]);

                }
            }
        
    }
}

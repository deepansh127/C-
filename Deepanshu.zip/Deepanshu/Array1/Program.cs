﻿using System;

namespace Array1
{
    class Program
    {
        public static void Main(string[] args)
        {
            Practice.Delete();


        }
    }
}

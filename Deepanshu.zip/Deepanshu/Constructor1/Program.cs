﻿using System;

namespace Constructor1
{   
    public class Student
    {
        public static decimal Salary1=11000;
       
    }
    public class Employee
    {
        string Fname, Lname;
        decimal Salary;
        int x;
       public Employee(string fname,string lname,decimal salary)
        {
            Fname = fname;
            Lname = lname;
            Salary = salary;
        }
        public void printDetails()
        {
            Console.WriteLine("Employee First Name : " + Fname);
            Console.WriteLine("Employee Last Name : " + Lname);
            Console.WriteLine("Employee Salary : " + Salary);
        }
        public Employee(Employee emp)
        {
            Fname = emp.Fname;
            Lname = emp.Lname;

            Salary = emp.Salary;
        }

        static void Main(string[] args)
        {
          
            Employee emp = new Employee("Rakesh", "Kumar", 12000);
            Employee emp2 = new Employee("Mahesh ", "rana", 1200);
            Employee emp1 = new Employee(emp);
            emp.printDetails();
            Console.WriteLine("------Update------");
            emp.Salary = 5000;
            emp.Lname = "Singh";
            emp.printDetails();
            Console.WriteLine("------Old Date-------");
            emp1.printDetails();
            Console.WriteLine("-----Rana-----");
            emp2.printDetails();
        }
        static Employee()
        {

            Console.WriteLine("Static Constructor");
        }



        //Employee emp1 = new Employee(20);
        //Console.WriteLine(emp1.x);
        //Console.ReadLine();

    }
    class Program
    {
       
    }
}

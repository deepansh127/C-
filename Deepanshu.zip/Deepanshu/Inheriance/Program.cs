﻿using System;

namespace Inheritance
{   
    internal class Customer

    {  static Customer()
        {
            Console.WriteLine("Static Constructor customer");
        }
        public Customer()
        {
            Console.WriteLine(" Parent Constructor ");
        }

        public int Id{ get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public decimal Amount { get; set; }
       
        public string GetFullName()
        {
            return Fname + " " + Lname;
        }
    }
    internal class GoldCustomer : Customer

    {
        static GoldCustomer()
        {
            Console.WriteLine("static constructor of GoldCustomer");
        }
      /*  public GoldCustomer(decimal Amount)
        {
            this.Amount = Amount;
        }*/
    }
    internal class RegularCustomer:Customer
    {

    }
    class Program
    {
        static void Main(string[] args)
        {

            //  GoldCustomer obj = new GoldCustomer(1000);


            GoldCustomer obj = new GoldCustomer();
             obj.Id = 102;
            obj.Fname = "Amit";
            obj.Lname = "Singh";
               

               Console.WriteLine($"Id : {obj.Id} ,{obj.GetFullName()} , Amount : {obj.Amount}");

               
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interface
{
   internal  interface I1
    {
        void GetData();
        void DisplayData();
        string Greet(string name);
    }
    class Employee : I1
    {
        int empId;
        string empName;
        double empSalary;
        public void DisplayData()
        {
            Console.WriteLine($"Employee Id is : {empId} ,Employee Name is : {empName} and Salary is :{empSalary}");
        }
        public void GetData()
        {
            Console.WriteLine("Enter Employee Details : ");
            empId = Convert.ToInt32(Console.ReadLine());
            empName = Console.ReadLine();
            empSalary = Convert.ToDouble(Console.ReadLine());

        }
        public string Greet(string Name)
        {
            return "Welcome " + Name;
        }
    }

}

﻿using System;

namespace Interface
{
   internal interface ICustomerAutho
    {
        public void Login();
        public void Logout();
        public string ResetPassWord();
    }
    internal interface ICustomerCrud
    {
        public void Create();
        public void Update();
        public void Delete();
        public void GetAll();

    }
    internal class CustomerService : ICustomerAutho
    {
//------------------------------------------------------------------------//
        public void Login()
        {
            SendOtp();
            ValidateDbData();
            Console.WriteLine(" Login Success");
        }
        public bool SendOtp()
        {
            Console.WriteLine("Otp Send ");
            return true;
        }
        public bool ValidateDbData()
        {
            Console.WriteLine("Data Validtae");
            return true;
        }
//---------------------------------------------------------------------//
        public void Logout()
        {
            ClearSessionInfo();
            Console.WriteLine("Logout Success");
        }
        public bool ClearSessionInfo()
        {
            Console.WriteLine("Session Data Cleared");
            return true;
        }
        public string  ResetPassWord()
        {

            Console.WriteLine("Password reset Changed");
            return "Nitish";
        }
//----------------------------------------------------------------------//
        public void Create()
        {
            Console.WriteLine("Customer  Created");
        }
        public void Update()
        {
            Console.WriteLine("customer updated");
        }
        public void Delete()
        {
            Console.WriteLine("Customer Delete");
        }
        public void GetAll()
        {
            Console.WriteLine("all customer Headed");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            /*
             ICustomerAutho autho = new CustomerService();
             autho.Login();
             autho.Logout();
             Console.WriteLine( autho.ResetPassWord());
            */
             

            /*ICustomerCrud crud = new CustomerService();
            crud.Create();
            crud.Update();
            crud.GetAll();
            crud.Delete();   */
            /*I1 emp = new Employee();
            Console.WriteLine(emp.Greet("Srikanth"));
            emp.GetData();
            emp.DisplayData();  */
          /* class2 o = new class2();
            I3 i = o;
             i.F3();
            A1 i1 = o;
             i1.F3();*/
            
         //   Ab a = new child();
           // a.z();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForLoop
{
    class P
    {
        public static void Get()
        {
            for(int i=1;i<=5;i++)
                
            {
                Console.WriteLine();
            }
        }
    }
}

﻿using System;

namespace Array
{
    class Program
    {
       public static void Main(string[] args)
        {
            occurence.Num();
        }
    }
}

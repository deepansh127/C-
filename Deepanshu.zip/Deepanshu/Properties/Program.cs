﻿using System;

namespace Properties
{
    class Employee
    {
        //  int empId;string empName;double salary;

        // assign data to variable from ourside
        int name;
        public int Qty
          {       
            set;
            get;
           }
        //read the data from variable to outside
        public string ProName
        {
            set;
            get;
        }
        public double Price
        {
            set;
            get;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            /* Employee e = new Employee();
             Console.WriteLine(" Enter Product Details ");
             e.Qty = int.Parse(Console.ReadLine());
             e.ProName = Console.ReadLine();
             e.Price = double.Parse(Console.ReadLine());
          //   e.Salary = 5000;

             Console.WriteLine($"Producct Name :{e.ProName} ,and Total Cost is: {e.Qty*e.Price}");
                 */
            Console.WriteLine("hello");
            BankingCustomer cust = new BankingCustomer("SBI00123", "Rakesh", 20000);
            Console.WriteLine("Customer Account Number : " + cust.AcNo);
            Console.WriteLine("Customer Name : " + cust.Name);
            Console.WriteLine("Customer Amount : " + cust.Amount);
            cust.Amount -= 18000;
            Console.WriteLine(" -----After trans-----");
            Console.WriteLine("Customer Account Number : " + cust.AcNo);
            Console.WriteLine("Customer Name : " + cust.Name);
            Console.WriteLine("  ====  ====");
            Console.WriteLine("Customer Amount : " + cust.Amount);
            Console.WriteLine("  ========");
            cust.N = 10;
            Console.WriteLine(cust.N);


        }
    }
}

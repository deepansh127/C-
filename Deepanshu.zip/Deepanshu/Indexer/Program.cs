﻿using System;

namespace Indexer
{

    class Products
    {
        public int Id { get; set; }
        public string Tittle { get; set; }
        public decimal Price { set; get; }
        public string Image { set; get; }
        public object this[int index]
        {
            set
            {
                if (index == 0)
                    this.Id = (int)value;
                else if (index == 1)
                    this.Tittle = (string)value;
                else if (index == 2)
                    this.Price = Convert.ToDecimal(value);
                else if (index == 3)
                    this.Image = (string)value;
                else
                    throw new Exception("Invalid Index Position ");
            }
            get
            {
                if (index == 0)
                    return this.Id;
                if (index == 1)
                    return this.Tittle;
                if (index == 2)
                    return this.Price;
                if (index == 3)
                    return this.Image;
                else
                    throw new Exception("Invalid Index Position ");
            }
        }
        public object this[string key ]
        {
            set
            {
                if (key.ToLower()=="id")
                    this.Id = (int)value;
                else if (key.ToLower() == "tittle")
                    this.Tittle = (string)value;
                else if (key.ToLower()== "price")
                    this.Price = Convert.ToDecimal(value);
                else if (key.ToLower()== "image")
                    this.Image = (string)value;
                else
                    throw new Exception("Invalid Index Position ");
            }
            get
            {
                if (key.ToLower() == "id")
                    return this.Id;
                if (key.ToLower()== "tittle")
                    return this.Tittle;
                if (key.ToLower() == "price")
                    return this.Price;
                if (key.ToLower() == "image")
                    return this.Image;
                else
                    throw new Exception("Invalid Index Position ");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Products p = new Products();
            p[0] = 101;
            p["tittle"] = "Laptop";
            p[2] = 20000;
             p[3]   = "test.png";
            Console.WriteLine("Id is : " + p["id"]);
            Console.WriteLine("Tittle : "+p[1]);
            Console.WriteLine("Price : "+p[2]);
            Console.WriteLine(" Image : " + p[3]);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection1
{
   internal class Employee
    {
        public int Id;
        public string  Name;
        public string Gender;
        public double Salary;
        public string EmailId;
       

    }
    class Program1
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee()
            {
                Id = 101,
                Name = "Adams",
                EmailId = "adams34@gmail.com",
                Salary = 21000,
                Gender = "Male"
            };
            Employee emp2 = new Employee()
            {
                Id = 102,
                Name = "Danis",
                EmailId = "dannis21@gmail.com",
                Salary = 31000,
                Gender = "Male"
            };
            Employee emp3= new Employee()
            {
                Id = 103,
                Name = "Annie",
                EmailId = "annie12@gmail.com",
                Salary = 25000,
                Gender = "Female"
            };
            Employee emp4 = new Employee()
            {
                Id = 104,
                Name = "Raju.",
                EmailId = "srikanth65@gmail.com",
                Salary = 45000,
                Gender = "Male"
            };
            Employee emp5 = new Employee()
            {
                Id = 105,
                Name = "Lavi.",
                EmailId = "lavi60@gmail.com",
                Salary = 37000,
                Gender = "Female"
            };
            
            List<Employee> emp = new List<Employee>();
            emp.Add(emp1);
            emp.Add(emp2);
            emp.Add(emp3);
            emp.Add(emp4);
            
            Console.WriteLine($"EmpId  EmpName    EmpSalary  EmpGender  EmpEmailId");
           
            emp.Add(emp5);
            foreach(var em in emp)
            {
                Console.WriteLine($"{em.Id}    {em.Name}       {em.Salary}     {em.Gender}       {em.EmailId}");
            }
            emp1.EmailId = "dubeyaishwarya480@gmail.com";
            Console.WriteLine("update----------------");
            foreach (var em in emp)
            {
                Console.WriteLine($"{em.Id}    {em.Name}       {em.Salary}     {em.Gender}       {em.EmailId}");
            }

            Console.WriteLine("Enter EmailId you want to update");
            string up = Console.ReadLine();

            bool t = true;
            foreach (var em in emp)
            {
                if (up.Equals(em.EmailId))
                {
                    t = false;
                    Console.WriteLine("Enter new EmailId");
                    
                    em.EmailId = Console.ReadLine();
                    Console.WriteLine($"{em.Id}    {em.Name}       {em.Salary}     {em.Gender}       {em.EmailId}");
                    break;
                }
            }
            if(t)
                Console.WriteLine("Email invalid");
            Console.WriteLine("Enter Employee Id you want to remove ");
            int Id = Convert.ToInt32(Console.ReadLine());

            foreach(var em in emp)
            {
                if (em.Id == Id)
                { emp.Remove(em);             
                    break;
                }
            }

            Console.WriteLine("remove--------"); 
            foreach (var em in emp)
            {
                Console.WriteLine($"{em.Id}    {em.Name}       {em.Salary}     {em.Gender}       {em.EmailId}");
            }
            Console.WriteLine("search---------------- ");
            Console.WriteLine("Enter Employee Id you want to search ");
            int Id1 = Convert.ToInt32(Console.ReadLine());
            bool c = true;
            foreach (var em in emp)
            {
                if (em.Id == Id1)
                {
                    c=false;
                    Console.WriteLine($"{em.Id}    {em.Name}       {em.Salary}     {em.Gender}       {em.EmailId}");

                    break;
                }
            }
             if(c)
                Console.WriteLine("Id invalid");

             
            

            
        }
    }
}

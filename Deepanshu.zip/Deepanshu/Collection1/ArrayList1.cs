﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection1
{
    class ArrayList1
    {

        static void Main(string[] args)
        {
            


        }
    }
}

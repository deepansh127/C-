﻿using System;

namespace Assesment4
{
    class Program
    {
        static void Main(string[] args)
        {
            #region quest -1  separate username and domain 
            /*
             Console.WriteLine(" Enter Email Address :");
            string str = Console.ReadLine();
            string[] str1 = str.Split("@");
            Console.WriteLine("\nUserName : " + str1[0]);
            Console.WriteLine("\nDomain : " + str1[1]);
            */
            #endregion

            #region quest-2  print abbreviation form

            /*Console.WriteLine("Enter name");
             string str = Console.ReadLine();
             string[] str1 = str.Split(" ");
             string Abbr = string.Empty;
             for (int i = 0; i < str1.Length-1; i++)
             {
                 Abbr += str1[i].Substring(0, 1).ToUpper() + ". ";
             }
             Abbr += str1[str1.Length - 1].Substring(0, 1).ToUpper() + str1[str1.Length - 1].Substring(1) ;
                     Console.WriteLine(Abbr);
            */

            #endregion

            #region quest-3  print capital case
            /*
             Console.WriteLine(" Enter name");
             string str = Console.ReadLine();
             String[] str1 = str.Split(" ");
             string Abbr = string.Empty;
             for(int i=0;i<str1.Length;i++)
             {
                 Abbr += str1[i].Substring(0, 1).ToUpper() + str1[i].Substring(1) + " ";
             }
             Console.WriteLine(Abbr);
            */
            #endregion

            #region quest-4 count specific word
            /*Console.WriteLine("Enter any string : ");
            string str = Console.ReadLine();
            Console.WriteLine("Enter Word ? ");
            string word = Console.ReadLine();
            int count = 0;
            foreach(var s in str.Split(" "))
            {
                if(s.ToLower()==word.ToLower())
                {
                    count++;
                }
            }
            Console.WriteLine(" Word : " + word + " , founnd : " + count + " time");
        
            */
            #endregion

            #region quest-5 check the string is palindrome or not
            /*
             Console.WriteLine("Enter any string");
             string str = Console.ReadLine();
             bool b = isPalindrome(str);
             if(b)
             {
                 Console.WriteLine("\n Yes Palindrome");
             }
             else
             {
                 Console.WriteLine("\n No Palindrome");
             }

             bool isPalindrome(string str)
             {
                 for(int i=0;i<str.Length/2;i++)
                 {
                     int n = str.Length;
                     if (str[i] != str[n - i - 1])
                         return false;
                 }
                 return true;
             }  
            */
            #endregion


            Console.WriteLine(Math.Round(4.3));

            Console.WriteLine(Math.Ceiling(4.4));
            Console.WriteLine(Math.Floor(4.9));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FileHandling
{
    class Log
    {
        public static void WriteLog(Exception ex)
        {
            string LogPath = @"D:\\ErrorLog";
            string s = DateTime.Now.ToString("dd/MM/yyyy");
            string fileName = "Log_" + s.Replace("/", "_") + ".text";
            string fullPath = Path.Combine(LogPath, fileName);
            if (File.Exists(fullPath))
            {
                FileStream fs = new FileStream(fullPath, FileMode.Append);
                StreamWriter writer= new StreamWriter(fs);
                string msg = "==========Error=========" + Environment.NewLine;
                msg += "Date time : " + DateTime.Now.ToString() + Environment.NewLine;
                msg += "Error Message :" + ex.Message + Environment.NewLine;
                msg += " Source : " + ex.Source + Environment.NewLine;
                msg += "Trace Info : " + ex.StackTrace + Environment.NewLine;
                writer.WriteLine(msg);
                writer.Close();

            }
            else
            {
                FileStream fs = new FileStream(fullPath, FileMode.OpenOrCreate);
                StreamWriter writer = new StreamWriter(fs);
                string msg = "==========Error=========" + Environment.NewLine;
                msg += "Date time : " + DateTime.Now.ToString() + Environment.NewLine;
                msg += "Error Message :" + ex.Message + Environment.NewLine;
                msg += " Source : " + ex.Source + Environment.NewLine;
                msg += "Trace Info : " + ex.StackTrace + Environment.NewLine;
                writer.WriteLine(msg);
                writer.Close();

            }
        }

    }
}

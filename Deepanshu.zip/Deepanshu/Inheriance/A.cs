﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class A
    {
        public string M1 => "I am from A Class";
    }
    class B : A
    {
        public string M2 => " I am from B class";
    }
    class C : B
    {
        public string M3 => " I am from C class";
    }
    class D : C
    {
        public string M4 => "I am from D class";
    }
    
    class Program3
    {
        public static void Main(string[] args)
        {
            D obj = new D();
            Console.WriteLine(obj.M4);
            B obj1 = obj;
            Console.WriteLine(obj1.M2);
            A obj2 = obj1;
            Console.WriteLine(obj2.M1);

        }
    }

}

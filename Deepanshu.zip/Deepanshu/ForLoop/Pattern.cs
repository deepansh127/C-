﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForLoop
{
    internal class Pattern
    {

        public static void A()
        {
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 9; j++)
                {
                    if ((i == 1 && j == 5) || (i == 2 && (j == 4 || j == 6)) || (i == 3 && (j >= 3 && 7 >= j)) || (i == 4 && (j == 2 || j == 8)) || (i == 5 && (j == 1 || j == 9)))
                    {
                        Console.Write(" *");
                    }
                    else
                    {
                        Console.Write("  ");
                    }
                }
                Console.WriteLine();
            }
        }
        public static void B()
        {
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    if (((i == 1 || i == 5 || i == 3) && (j <= 5)) || ((i == 2 || i == 4) && (j == 1 || j == 5)))
                    {
                        Console.Write(" *");
                    }
                    else
                    {
                        Console.Write("  ");
                    }
                }
                Console.WriteLine();
            }
        }
        public static void C()
        {
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    if (((i == 1 || i == 5) && (j <= 5)) || (i <= 5 && j == 1))
                    {
                        Console.Write(" *");
                    }
                    else
                    {
                        Console.Write("  ");
                    }
                }
                Console.WriteLine();
            }
        }
        public static void H()
        {
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    if (((i == 3) && (j <= 5)) || (i <= 5 && (j == 1 || j == 5)))
                    {
                        Console.Write(" *");
                    }
                    else
                    {
                        Console.Write("  ");
                    }
                }
                Console.WriteLine();
            }
        }
            public static void D()
            {
                for (int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (((i == 1 || i == 5) && (j <= 5)) || ((i == 2 || i == 4 || i == 3) && (j == 1 || j == 5)))
                        {
                            Console.Write(" *");
                        }
                        else
                        {
                            Console.Write("  ");
                        }
                    }
                    Console.WriteLine();
                }
            }
            public static void E()
            {
                for (int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (((i == 1 || i == 5 || i == 3) && (j <= 5)) || ((i == 2 || i == 4) && (j == 1)))
                        {
                            Console.Write(" *");
                        }
                        else
                        {
                            Console.Write("  ");
                        }
                    }
                    Console.WriteLine();
                }
            }
            public static void G()
            {
                for (int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (((i == 1 || i == 5) && (j <= 5)) || ((i == 2 || i == 4 || i == 3) && (j == 1)) || (i == 4 && j == 5) || (i == 3 && (j == 4 || j == 5)))
                        {
                            Console.Write(" *");
                        }
                        else
                        {
                            Console.Write("  ");
                        }
                    }
                    Console.WriteLine();
                }
            }
            public static void Z()
            {
                for (int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (((i == 1 || i == 5) && (j <= 5)) || (i == 2 && j == 4) || (i == 3 && j == 3) || (i == 4 && j == 2))
                        {
                            Console.Write(" *");
                        }
                        else
                        {
                            Console.Write("  ");
                        }
                    }
                    Console.WriteLine();
                }
            }
            public static void K()
            {
                for (int i = 1; i <= 7; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (((j == 1) && (i <= 7)) || (i == 4 && j == 2) || (i == 3 && j == 3) || (i == 2 && j == 4) || (i == 1 && j == 5) || (i == 5 && j == 2) || (i == 6 && j == 3) || (i == 7 && j == 4))
                        {
                            Console.Write(" *");
                        }
                        else
                        {
                            Console.Write("  ");
                        }
                    }
                    Console.WriteLine();
                }
            }



        
    }

}
﻿using System;

namespace FileHandling
{

    




    class Program
    {
        static void Main(string[] args)
        {

            Content.AllContent();

            //try
            //{
            //    Console.WriteLine("Enter Ist Number");
            //    int n1 = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("Enter 2nd Number");

            //    int n2 = Convert.ToInt32(Console.ReadLine());
            //    int z = n1 / n2;
            //    Console.WriteLine("Result : "+z);
            //}
            //catch(Exception ex)
            //{
            //    Log.WriteLog(ex);
            //}
            
        }
    }
}
